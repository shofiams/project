class ApiServices {
  static String login_api_url = 'https://127.0.0.1:8000/api/login';
  static String username = 'username';
  static String password = 'password';
}

class UserInfo {
  static String userID = 'id';
  static String userName = 'name';
  static String userEmail = 'email';
}
