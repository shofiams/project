class UserDataList {
  static String uid = '';
  static String email = '';
  static String token = '';
}

class UserInfoModel {
  var uid;
  var email;

  UserInfoModel({
    this.uid,
    this.email,
  });
}
